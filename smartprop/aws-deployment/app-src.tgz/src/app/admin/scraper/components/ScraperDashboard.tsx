'use client';

import { useState, useEffect } from 'react';
import { AuthStatusCard } from './AuthStatusCard';
import { DataQualityDashboard } from './DataQualityDashboard';
import { ScraperConfigForm } from './ScraperConfigForm';
import { LiveProgressPanel } from './LiveProgressPanel';
import { RecentListingsPreview } from './RecentListingsPreview';
import { HistoryTable } from './HistoryTable';
import { getDistrictMetadata, forceResetStuckJobs } from '../actions';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

interface Job {
  id?: string;
  platform?: string;
  listingsProcessed?: number;
  totalPages?: number;
  currentPage?: number;
  currentDistrict?: string;
  statusMessage?: string;
  stats?: {
    totalSuccess?: number;
    saved?: number;
    totalSkippedNoPhone?: number;
    skipped?: number;
    totalErrors?: number;
    errors?: number;
  };
  [key: string]: unknown;
}

interface District {
  district: string;
  last_scraped_at: string | null;
  total_listings: number;
  last_phone_success_rate: number | null;
  is_favorite: boolean;
}

interface AuthStatus {
  propertyguru: { isAuthenticated: boolean; lastAuth: string | null };
  edgeprop: { isAuthenticated: boolean; lastAuth: string | null };
}

interface QualityMetrics {
  completenessScore: number;
  phoneValidationRate: number;
  duplicatesToday: number;
  staleListings: number;
}

interface JobHistory {
  id: string;
  platform: string;
  status: string;
  started_at: string;
  completed_at: string | null;
  listings_processed: number;
  config?: {
    district?: string;
    pages?: number;
  };
  stats?: {
    saved?: number;
    skipped?: number;
    errors?: number;
  };
}

interface ScraperDashboardProps {
  initialActiveJob: Job | null;
  initialJobHistory: JobHistory[];
  initialDistricts: District[];
  initialQualityMetrics: QualityMetrics;
  initialAuthStatus: AuthStatus;
}

export function ScraperDashboard({
  initialActiveJob,
  initialJobHistory,
  initialDistricts,
  initialQualityMetrics,
  initialAuthStatus
}: ScraperDashboardProps) {
  const [activeJob, setActiveJob] = useState(initialActiveJob);
  const [authStatus, setAuthStatus] = useState(initialAuthStatus);
  const [qualityMetrics, setQualityMetrics] = useState(initialQualityMetrics);
  const [districts, setDistricts] = useState(initialDistricts);
  const [lastJobId, setLastJobId] = useState<string | null | undefined>(initialActiveJob?.id);
  const [isResetting, setIsResetting] = useState(false);

  const handleForceReset = async () => {
    if (!confirm('Are you sure you want to force reset all stuck jobs? This will mark all active jobs as failed and clear lock files. Use this if you cannot start a new scrape.')) {
      return;
    }
    
    setIsResetting(true);
    try {
      const result = await forceResetStuckJobs();
      if (result.success) {
        toast.success(result.message || `Reset ${result.jobsReset || 0} stuck job(s)`);
        setActiveJob(null);
        setLastJobId(null);
        // Wait longer to ensure database update completes and propagates
        setTimeout(() => {
          // Force a hard reload to clear any cached state
          window.location.href = window.location.href.split('#')[0];
        }, 1500);
      } else {
        toast.error(result.error || 'Failed to reset stuck jobs');
        setIsResetting(false);
      }
    } catch (error) {
      toast.error('Failed to reset stuck jobs');
      console.error('Error resetting stuck jobs:', error);
      setIsResetting(false);
    }
  };

  // Connect to SSE for real-time updates
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let reconnectTimeout: NodeJS.Timeout | null = null;

    const connectSSE = () => {
      try {
        eventSource = new EventSource(`${window.location.origin}/api/scraper/status`);

        eventSource.onopen = () => {
          console.log('SSE connection opened');
        };

        eventSource.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            
            if (data.status === 'active' && data.job) {
              setActiveJob(data.job);
            } else if (data.status === 'idle') {
              // Job just completed! Refresh district metadata
              const refreshDistricts = async () => {
                const result = await getDistrictMetadata();
                if (result.success) {
                  setDistricts(result.districts);
                  toast.success('✅ Scrape complete! District data refreshed');
                }
              };
              
              // Only refresh if we had a job running
              if (lastJobId) {
                refreshDistricts();
              }
              
              setActiveJob(null);
              setLastJobId(null);
            }
          } catch (error) {
            console.error('Error parsing SSE message:', error);
            console.error('Raw event data:', event.data);
          }
        };

        eventSource.onerror = (event) => {
          const readyState = eventSource?.readyState;
          const url = eventSource?.url;
          
          // Log useful information about the error
          console.error('SSE error occurred:', {
            readyState: readyState,
            readyStateName: readyState === EventSource.CONNECTING ? 'CONNECTING' : 
                           readyState === EventSource.OPEN ? 'OPEN' : 
                           readyState === EventSource.CLOSED ? 'CLOSED' : 'UNKNOWN',
            url: url,
            type: event.type,
            target: event.target
          });
          
          // Close current connection
          if (eventSource && eventSource.readyState !== EventSource.CLOSED) {
            eventSource.close();
          }
          
          // Reconnect after 3 seconds if not manually closed and not already reconnecting
          if (readyState === EventSource.CLOSED) {
            reconnectTimeout = setTimeout(() => {
              console.log('Reconnecting to SSE...');
              connectSSE();
            }, 3000);
          }
        };
      } catch (error) {
        console.error('Error creating EventSource:', error);
      }
    };

    // Start the connection
    connectSSE();

    return () => {
      if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
      }
      if (eventSource && eventSource.readyState !== EventSource.CLOSED) {
        eventSource.close();
      }
    };
  }, [lastJobId]);

  return (
    <div className="space-y-6">
      {/* Force Reset Button - Always visible */}
      {!activeJob && (
        <div className="flex justify-end">
          <Button
            onClick={handleForceReset}
            disabled={isResetting}
            variant="outline"
            size="sm"
            className="border-amber-500 text-amber-700 hover:bg-amber-50"
          >
            {isResetting ? 'Resetting...' : 'Force Reset Stuck Jobs'}
          </Button>
        </div>
      )}

      {/* Authentication Status */}
      <AuthStatusCard 
        authStatus={authStatus}
        onAuthStatusChange={setAuthStatus}
      />

      {/* Data Quality Metrics */}
      <DataQualityDashboard metrics={qualityMetrics} />

      {/* Live Progress (only show if active job) */}
      {activeJob && (
        <LiveProgressPanel 
          job={activeJob} 
          onJobStopped={() => {
            setActiveJob(null);
            setLastJobId(null);
          }}
        />
      )}

      {/* Scraper Configuration Form */}
      <ScraperConfigForm
        districts={districts}
        disabled={!!activeJob}
        onJobStarted={(job) => {
          setActiveJob(job);
          setLastJobId(job.id);
        }}
      />

      {/* Recent Listings */}
      <RecentListingsPreview />

      {/* History Table */}
      <HistoryTable 
        initialHistory={initialJobHistory} 
        onHistoryChanged={() => {
          // No need to refresh - the table updates its own state
          console.log('History updated');
        }}
      />
    </div>
  );
}

