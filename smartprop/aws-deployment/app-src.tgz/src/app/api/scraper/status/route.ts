import { NextRequest } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE!;

/**
 * Server-Sent Events endpoint for real-time scraper status updates
 * 
 * Usage from client:
 *   const eventSource = new EventSource('/api/scraper/status');
 *   eventSource.onmessage = (event) => {
 *     const status = JSON.parse(event.data);
 *     // Update UI
 *   };
 */
export async function GET(request: NextRequest) {
  const encoder = new TextEncoder();

    const stream = new ReadableStream({
    async start(controller) {
      let isClosed = false;
      const supabase = createClient(supabaseUrl, supabaseKey);

      // Send keepalive message every 30 seconds to keep connection alive
      const keepaliveInterval = setInterval(() => {
        if (!isClosed) {
          try {
            controller.enqueue(encoder.encode(`: keepalive\n\n`));
          } catch (error) {
            console.error('Error sending keepalive:', error);
            isClosed = true;
          }
        }
      }, 30000);

      // Send initial status
      const sendStatus = async () => {
        if (isClosed) return;
        
        try {
          // Get active job from database
          const { data: job, error: queryError } = await supabase
            .from('scraper_jobs')
            .select('*')
            .in('status', ['queued', 'running'])
            .order('started_at', { ascending: false })
            .limit(1)
            .single();

          if (queryError && queryError.code !== 'PGRST116') { // PGRST116 = no rows returned
            console.error('Error querying scraper_jobs:', queryError);
            if (!isClosed) {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'error', error: queryError.message })}\n\n`));
            }
            return;
          }

          if (!job) {
            if (!isClosed) {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'idle' })}\n\n`));
            }
            return;
          }

          // Read lock file for real-time progress
          let progress = {
            currentDistrict: job.current_district,
            currentPage: job.current_page,
            listingsProcessed: job.listings_processed
          };
          let statusMessage = 'Scraping...';
          let realtimeStats = job.stats;

          try {
            const lockFile = path.join(process.cwd(), 'storage',
              job.platform === 'propertyguru' ? 'pg-scraper.lock' : 'ep-scraper.lock');
            
            if (fs.existsSync(lockFile)) {
              const lockData = JSON.parse(fs.readFileSync(lockFile, 'utf-8'));
              progress = lockData.progress || progress;
              statusMessage = lockData.statusMessage || statusMessage;
              // Use real-time stats from lock file if available
              realtimeStats = lockData.stats || job.stats;
            }
          } catch (fileError: any) {
            // Non-fatal error - just use database values
            console.warn('Error reading lock file:', fileError?.message);
          }

          const statusData = {
            status: 'active',
            job: {
              id: job.id,
              platform: job.platform,
              status: job.status,
              config: job.config,
              ...progress,
              totalPages: job.total_pages,
              stats: realtimeStats,
              startedAt: job.started_at,
              statusMessage: statusMessage
            }
          };

          if (!isClosed) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(statusData)}\n\n`));
          }

        } catch (error: any) {
          console.error('Error sending status:', error);
          if (!isClosed) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'error', error: String(error?.message || error) })}\n\n`));
          }
        }
      };

      // Send status every 2 seconds
      try {
        await sendStatus();
      } catch (error) {
        console.error('Error in initial sendStatus:', error);
      }
      
      const interval = setInterval(() => {
        if (!isClosed) {
          sendStatus().catch((error) => {
            console.error('Error in periodic sendStatus:', error);
          });
        }
      }, 2000);

      // Cleanup on disconnect
      request.signal.addEventListener('abort', () => {
        isClosed = true;
        clearInterval(interval);
        clearInterval(keepaliveInterval);
        try {
          controller.close();
        } catch (error) {
          // Ignore errors on close
        }
      });
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}

